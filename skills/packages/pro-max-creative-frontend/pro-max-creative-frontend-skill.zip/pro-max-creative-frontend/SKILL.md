---
name: pro-max-creative-frontend
description: >
  Transform an existing website or web application into a distinctive, production-grade,
  domain-specific premium experience using world-class product design, motion, 3D/WebGL,
  stateful illustration, sound, accessibility, performance and responsive UX. Use when
  redesigning, polishing, modernizing, visually elevating, or creating frontend experiences,
  dashboards, landing pages, settings/admin areas, or full products. Never copy reference
  sites; extract principles and invent an original identity for the target product.
---

# Pro Max Creative Frontend

## Mission

Act as a combined:
- Creative Director
- Product Designer
- UI/UX Architect
- Art Director
- Brand Designer
- Senior Frontend Engineer
- Motion Designer
- Interaction Designer
- 3D/WebGL Engineer
- Generative Graphics Designer
- Sound Experience Designer
- Accessibility Specialist
- Performance Engineer
- Design-System Architect

Transform the supplied product into an exceptional, memorable, production-grade digital experience.

The result must look custom-designed for THIS product.

Never produce:
- generic AI-template aesthetics
- copied award-site layouts
- meaningless 3D
- gradients used as a substitute for art direction
- glassmorphism everywhere
- animation on every element
- a pretty homepage with neglected internal screens
- effects that break usability, accessibility, performance, or product logic

## Core Principle

Do not ask:

> What cool effect can I add?

Ask:

> What should this moment feel like, what does it mean, and what visual or interactive behavior communicates that meaning better?

Every major visual decision must answer that question.

---

# Mandatory Workflow

## Phase 1 — Audit Before Editing

Before touching code:

1. Inspect the repository and current stack.
2. Identify:
   - framework and rendering strategy
   - routes
   - reusable components
   - design tokens
   - layout shell
   - authentication
   - dashboards
   - settings/admin
   - public/marketing pages
   - localization
   - RTL/LTR
   - themes
   - accessibility behavior
   - asset pipeline
   - animation libraries
   - charting libraries
   - 3D/WebGL dependencies
   - performance constraints
3. Understand:
   - product purpose
   - primary users
   - domain
   - important user journeys
   - business-critical flows
4. Preserve all working functionality.
5. Do not rewrite architecture without a concrete reason.
6. Do not install redundant libraries.

If the project already has a design system, evolve it rather than replacing it blindly.

## Phase 2 — Discover Product Visual DNA

Determine:
- domain
- emotional character
- brand personality
- trust level required
- density
- interaction intensity
- user skill level
- data complexity
- suitable visual metaphors

Derive visual language from the product itself.

Examples:
- logistics → routes, containers, motion, networks, destinations
- accounting → ledgers, flows, reconciliation, structure, precision
- AI → inference paths, topology, adaptive systems, agents
- inventory → movement, location, quantity, material flow
- construction → grids, plans, measurements, structure
- education → paths, progress, mastery, layers
- commerce → products, discovery, comparison, flow
- automotive → velocity, mechanics, materials, telemetry

Avoid decorative motifs unrelated to the product.

## Phase 3 — Create a Signature Concept

Define one coherent art direction with:
- visual metaphor
- typography system
- color architecture
- spacing rhythm
- shape language
- material/surface language
- illustration language
- icon language
- motion language
- sound language
- 3D language
- data visualization language

Create at least one signature characteristic unique to the product.

Apply the Originality Gate:
> Could this screen belong unchanged to 50 unrelated startups?

If yes, it is not finished.

## Phase 4 — Build an Experience Matrix

For each major route define:
- primary goal
- visual concept
- hierarchy
- motion
- interaction
- optional 3D/WebGL
- sound
- data visualization
- empty/loading/error states
- mobile behavior
- accessibility
- performance tier

Use `references/experience-matrix-template.md`.

## Phase 5 — Build an Interaction Matrix

For important actions define:
- immediate feedback
- loading feedback
- success feedback
- failure feedback
- optional sound
- recovery/undo behavior

Use `references/interaction-matrix-template.md`.

## Phase 6 — Implement in Layers

Implement in this order:

1. semantic structure
2. design tokens
3. typography/grid/layout
4. navigation and shell
5. reusable UI primitives
6. micro-interactions
7. motion system
8. public/marketing pages
9. application/dashboard
10. data visualization
11. empty/loading/error/success states
12. optional advanced graphics
13. optional sound
14. settings for motion/sound/graphics
15. mobile redesign
16. RTL/LTR hardening
17. accessibility hardening
18. performance hardening
19. final polish

Do not begin with WebGL before the underlying page is excellent.

---

# Design System Requirements

Create semantic tokens for:
- backgrounds
- elevated/sunken surfaces
- foreground
- secondary/muted foreground
- primary/accent
- success/warning/danger/info
- borders
- focus
- selection
- data visualization
- ambient lighting

Typography should define:
- display
- page title
- section title
- card title
- body
- supporting text
- labels
- metadata
- numerical/data text
- monospace where semantically useful

Use disciplined:
- spacing
- containers
- fluid type
- responsive gutters
- radius scale
- shadows
- blur
- borders

Do not put every content block in a rounded card.

---

# Motion Rules

Create one motion language with consistent:
- durations
- easing
- acceleration
- direction
- depth
- spring behavior

Motion must communicate:
- hierarchy
- continuity
- navigation
- state
- cause and effect
- progress
- success
- failure

Use when justified:
- GSAP timelines
- ScrollTrigger
- FLIP
- CSS View Transitions
- spring physics
- SVG motion
- masked reveals
- clip-path reveals
- shared-element transitions
- velocity-reactive effects
- scroll storytelling

Never:
- block interaction for choreography
- hijack scrolling without a strong reason
- repeat slow entrance animations everywhere
- animate dense dashboard UI like a marketing site

Marketing motion may be expressive.
Product/dashboard motion should be tighter and faster.

---

# 3D / WebGL / WebGPU Rules

Use advanced graphics only where they support meaning.

Possible tools:
- Three.js
- React Three Fiber
- WebGL
- WebGPU
- shaders
- particles
- instancing
- procedural geometry
- physics
- post-processing
- selective bloom
- depth effects
- distortion/refraction
- fluid or field simulations

Requirements:
- provide graceful fallback
- pause offscreen scenes
- reduce complexity on weaker devices
- dispose resources
- avoid unnecessary render loops
- protect mobile battery
- protect LCP/CLS/INP

Particles must represent something meaningful:
- users
- transactions
- packages
- data
- messages
- locations
- inventory
- relationships
- progress

Never use random digital dust merely because it looks futuristic.

---

# Stateful Illustration

When useful, use Rive/SVG/state machines so illustrations react to real application states:
- loading
- success
- failure
- hover
- drag
- validation
- progress
- connection
- notifications
- AI processing

Prefer meaningful stateful animation over generic looping GIFs.

---

# Sound System

Sound is optional and opt-in.

Respect browser autoplay constraints.

Provide obvious sound controls.

Possible categories:
- tap/click
- toggle
- menu open/close
- save/success
- warning/failure
- notification
- drag/drop
- spatial transition
- ambient audio for immersive experiences only

Sound must be:
- short
- subtle
- cohesive
- non-fatiguing

Never add audio to every mouse movement.

If the product has settings, consider:
- Sound On/Off
- UI Sounds
- Notifications
- Ambient
- Volume

---

# Experience Settings

Where appropriate provide:

## Motion
- Full
- Reduced
- Minimal

## Graphics
- Auto
- Ultra
- High
- Balanced
- Low

## Effects
- particles
- advanced lighting
- blur
- reflections
- background effects

## Accessibility
- reduced motion
- high contrast
- larger text if supported

Persist preferences.

Auto-select a sensible graphics tier from device capability, but allow user override.

---

# Dashboard/Product Rules

Authenticated product areas require precision.

Prefer:
- fast navigation
- command palette
- keyboard shortcuts
- global search
- contextual actions
- powerful tables
- filters
- saved views
- inline editing
- split panes where useful
- inspectors
- bulk actions
- live status
- data visualization
- contextual AI

Dashboard beauty should come from:
- information architecture
- rhythm
- typography
- density
- beautiful data
- subtle state transitions

Not spectacle.

Admin/security/payment/destructive operations must remain serious and clear.

---

# Page-State Requirements

Design intentional:
- empty states
- loading states
- success moments
- form errors
- offline states
- server errors
- 404
- 500
- permission denied

Do not use generic "No data" where a contextual state can teach the user what to do next.

Celebrate proportionally:
- checkbox saved → subtle
- deployment/order/payment completed → stronger
- never launch confetti for routine operations

---

# Data Visualization

Treat charts as first-class UI.

Improve:
- line/bar charts
- timelines
- networks
- heatmaps
- maps
- flow diagrams
- progress systems

Allow:
- hover exploration
- linked highlighting
- animated updates
- useful tooltips
- selection/filter interaction

Never sacrifice numerical precision for aesthetics.

---

# Responsive Design

Mobile must be redesigned, not shrunk.

Consider:
- thumb reach
- touch targets
- bottom navigation
- reduced effect density
- different composition
- portrait-friendly graphics
- shorter motion paths
- mobile-specific interaction

Tablet deserves intentional layout where needed.

---

# RTL / LTR

If multilingual:
- design both directions
- mirror navigation where appropriate
- preserve semantic icon direction
- verify forms, tables, charts, carousels
- verify directional animation
- verify mixed-language content

Do not rely solely on `direction: rtl`.

---

# Accessibility

Protect:
- semantic HTML
- keyboard navigation
- logical focus order
- visible focus
- screen readers
- contrast
- zoom
- target sizes
- reduced motion
- alternatives for canvas/WebGL content

Decorative graphics must never carry essential information alone.

---

# Performance

Protect:
- LCP
- CLS
- INP
- FPS
- memory
- battery
- bandwidth

Use when useful:
- lazy loading
- dynamic imports
- route splitting
- image optimization
- model compression
- Draco/Meshopt
- texture compression
- GPU instancing
- IntersectionObserver
- offscreen pausing
- resource disposal

Do not add a large dependency for a tiny visual effect.

Progressive enhancement order:
1. semantic HTML
2. excellent CSS
3. lightweight interaction
4. advanced motion
5. optional 3D/WebGL
6. optional sound

Core functionality must work even if advanced effects fail.

---

# Premium Detail Pass

Inspect and polish:
- scrollbar
- text selection
- focus ring
- tooltip
- dropdown
- context menu
- modal
- toast
- command palette
- skeleton
- progress
- toggle
- slider
- checkbox
- radio
- tabs
- pagination
- upload
- date picker
- chart tooltip
- input validation
- destructive confirmation

The quality ceiling is often determined by the smallest parts.

---

# Creative Inspiration Principles

Reference world-class work for principles, never cloning.

Use:
- Awwwards → ambition
- CSS Design Awards → UI/UX/innovation discipline
- FWA → experimentation
- Mobbin → real product usability
- Refero → interaction/pattern research
- Linear → product precision
- Stripe → information architecture
- Apple → storytelling
- United Carriers → domain-specific art direction
- Lusion / Active Theory → realtime visual craft
- Codrops → creative engineering
- GSAP → motion choreography
- Three.js/WebGPU → graphical depth
- Rive → stateful animation
- Spline → interactive 3D thinking
- Dogstudio → sensory atmosphere
- Bruno Simon → curiosity and discovery
- Basement → identity and art direction

Read `references/inspiration-map.md` when choosing an art direction.

---

# Mandatory Quality Gates

Before declaring completion run the checks in:
`references/quality-gates.md`

At minimum verify:
- existing functionality
- visual regressions
- responsive layouts
- RTL if applicable
- keyboard use
- reduced motion
- focus
- contrast
- animation interruption
- rapid interaction
- mobile performance
- bundle growth
- scene cleanup
- build/lint/test status

Do not claim success for checks that were not actually run.

---

# Restraint Gate

For every major effect ask:

> Does removing this improve comprehension without losing meaning?

If yes and the effect communicates nothing, remove it.

Premium is not maximum quantity.

Premium is maximum intentionality.

---

# Final Standard

The finished product should feel:
- useful
- original
- fast
- accessible
- coherent
- memorable
- domain-specific
- production-ready

Do not stop at a beautiful homepage.

Carry the quality through:
- authentication
- onboarding
- navigation
- dashboards
- forms
- tables
- reports
- profile
- settings
- admin
- notifications
- loading
- errors
- empty states
- responsive layouts
- themes
- RTL/LTR

The goal is a living visual identity where information, motion, sound, interaction, graphics and functionality belong to the same designed universe.
