# Pro Max Creative Frontend Skill

A reusable creative-frontend workflow for AI coding agents.

## What this package contains

- `SKILL.md` — main orchestration skill
- `references/inspiration-map.md` — what to extract from world-class references
- `references/experience-matrix-template.md` — route-by-route design planning
- `references/interaction-matrix-template.md` — action feedback planning
- `references/quality-gates.md` — completion/testing gates

## Installation concept

Install the `pro-max-creative-frontend` directory as a Skill in an Agent Skills-compatible product.

OpenAI describes Skills as reusable workflows centered around `SKILL.md`, with optional supporting resources. Codex can use installed skills automatically when relevant or when explicitly requested.

## Suggested Invocation

Use the `pro-max-creative-frontend` skill.

Deeply audit this repository first. Preserve all existing functionality and business logic. Derive a domain-specific visual identity from the actual product, create the route Experience Matrix, then progressively upgrade the full product including public pages, authenticated UI, dashboards, settings, admin, states, motion, accessibility, responsive behavior and performance. Use advanced 3D, WebGL, WebGPU, Rive or sound only when they strengthen meaning and pass the skill's restraint/performance gates.

## Design Philosophy

The skill intentionally separates:
- usability from spectacle
- product UI from marketing UI
- meaning from decoration
- progressive enhancement from hard dependencies
- premium craft from visual clutter

It is designed to produce a different visual identity for every product rather than repeating one aesthetic.
