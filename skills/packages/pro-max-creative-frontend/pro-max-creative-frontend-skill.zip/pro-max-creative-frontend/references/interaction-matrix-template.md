# Interaction Matrix Template

| Action | Immediate Feedback | Loading | Success | Failure | Sound | Undo / Recovery |
|---|---|---|---|---|---|---|
| Save |  |  |  |  |  |  |
| Create |  |  |  |  |  |  |
| Delete |  |  |  |  |  |  |
| Search |  |  |  |  |  |  |
| Upload |  |  |  |  |  |  |
| Drag/drop |  |  |  |  |  |  |
| Approve |  |  |  |  |  |  |
| Reject |  |  |  |  |  |  |
| Pay |  |  |  |  |  |  |
| Invite |  |  |  |  |  |  |
| Login |  |  |  |  |  |  |

## Interaction Rules

- Every action gets immediate feedback.
- Loading must not erase context.
- Prefer optimistic UI only when it is safe.
- Errors must explain recovery.
- Sound is optional and proportional.
- Destructive actions require clarity, not playfulness.
