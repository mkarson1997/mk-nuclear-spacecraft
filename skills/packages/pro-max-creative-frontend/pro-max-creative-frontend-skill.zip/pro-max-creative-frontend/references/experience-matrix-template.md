# Experience Matrix Template

Create this before large implementation.

| Route / Screen | Primary User Goal | Signature Visual Concept | Motion | 3D/WebGL | Sound | Data Viz | Empty/Loading/Error | Mobile Adaptation | Accessibility | Performance Tier |
|---|---|---|---|---|---|---|---|---|---|---|
| / |  |  |  |  |  |  |  |  |  |  |
| /login |  |  |  |  |  |  |  |  |  |  |
| /dashboard |  |  |  |  |  |  |  |  |  |  |
| /settings |  |  |  |  |  |  |  |  |  |  |

## Rules

- Do not give every route the same visual treatment.
- Public/marketing routes may be more expressive.
- Authenticated operational routes should prioritize speed and precision.
- Security/destructive workflows should remain restrained.
- Mark advanced effects as optional if they are not needed to understand the screen.
