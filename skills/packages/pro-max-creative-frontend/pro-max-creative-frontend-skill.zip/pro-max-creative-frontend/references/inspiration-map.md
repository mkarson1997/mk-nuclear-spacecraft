# Inspiration Map

Use this file to select principles, not layouts.

| Source | Extract | Never Copy |
|---|---|---|
| Awwwards | ambition, cinematic composition, interaction craft | page structure, exact effects |
| CSS Design Awards | UI, UX and innovation balance | award-site tropes |
| FWA | experimental digital behavior | novelty without purpose |
| Mobbin | validated product flows, real-world UX | app screenshots or product identity |
| Refero | component/pattern research | component clones |
| Linear | information density, precise dark UI, restrained motion | exact palette/layout |
| Stripe | hierarchy, technical storytelling, diagrams | signature Stripe gradients |
| Apple | staged storytelling, typography, product focus | exact scroll sequences |
| United Carriers | convert industry mechanics into visual language | trucks/containers in unrelated domains |
| Lusion | 3D storytelling, realtime scene composition | scene assets |
| Active Theory | WebGL craft and immersive systems | experimental effects without business meaning |
| Codrops | creative frontend techniques | demos pasted into production |
| GSAP Showcase | choreography and timing | identical timelines |
| Three.js | spatial rendering techniques | complexity for decoration |
| Rive | stateful animation | looping ornamental animation |
| Spline | interactive 3D composition | heavy embeds everywhere |
| Dogstudio | atmosphere and sensory cohesion | constant sound |
| Bruno Simon | curiosity, playful exploration | game mechanics in serious workflows |
| Basement | bold art direction and brand systems | fashionable brutality without fit |
| Behance | visual language, identity, illustration | presentation-only UX |
| Dribbble | micro ideas | fantasy UI that cannot function |

## Principle Fusion

Choose only principles that fit the product.

Example: Accounting platform
- Mobbin for product flows
- Linear for density
- Stripe for information hierarchy
- Codrops/GSAP for selective motion
- Rive for status animation
- accounting-native metaphors for originality

Example: Logistics platform
- United Carriers for domain art direction
- maps/routes as data
- GSAP for movement
- Three.js only if spatial storytelling helps
- Mobbin for operational UX

Example: AI platform
- topology, agents, stateful inference visualizations
- Rive for agent states
- Three.js/WebGPU for high-end public storytelling
- Linear for dense internal UI

Never combine every source at once.
Select the minimum set that produces one coherent identity.
