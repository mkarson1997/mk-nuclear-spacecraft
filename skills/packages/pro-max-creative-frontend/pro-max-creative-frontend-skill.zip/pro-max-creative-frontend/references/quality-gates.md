# Quality Gates

Do not declare the redesign complete until relevant gates pass.

## Functional
- Existing primary journeys still work.
- Business logic was not altered accidentally.
- Auth/session flows still work.
- Forms submit correctly.
- Validation still works.
- Permission boundaries still work.
- Destructive actions remain guarded.

## Build / Static
- Build passes.
- Type-check passes.
- Lint passes or known pre-existing exceptions are documented.
- Tests pass or failures are explicitly identified as pre-existing/new.

## Visual
- No overlap.
- No unintended clipping.
- No horizontal overflow.
- Typography remains readable.
- Long content does not break layout.
- Empty/loading/error states are intentional.
- Dark/light modes are coherent.

## Responsive
Check representative widths:
- small mobile
- large mobile
- tablet
- laptop
- desktop
- ultrawide if the product is desktop-heavy

## RTL / Localization
If applicable:
- navigation mirrors correctly
- icons mirror only when semantically directional
- forms/tables/charts remain usable
- mixed-language strings work
- animations respect direction

## Motion
- prefers-reduced-motion is respected.
- animations can be interrupted.
- rapid clicks do not corrupt UI state.
- navigation is not blocked by animation.
- scroll remains controllable.
- dashboard motion is concise.

## Accessibility
- keyboard-only navigation works.
- focus is visible.
- tab order is logical.
- dialogs trap/restore focus correctly.
- contrast is adequate.
- canvas/WebGL has accessible fallback where required.
- touch targets are appropriate.

## Performance
- compare bundle size before/after
- inspect LCP/CLS/INP where practical
- inspect mobile FPS for advanced scenes
- offscreen 3D pauses
- render loops stop when unnecessary
- textures/models are optimized
- resources are disposed
- no obvious memory leak
- graphics quality fallback works

## Originality Gate
Ask:
> Could this interface belong unchanged to dozens of unrelated products?

If yes, incorporate product-native visual language.

## Restraint Gate
Ask:
> Does this effect communicate meaning, hierarchy, continuity or state?

If no, remove or simplify it.

## Final Review
The product should remain:
- usable
- fast
- accessible
- coherent
- memorable
- unmistakably tied to its domain
